/**
 *
 * Get the contents for this file from Assignment 1
 * You dont have to add new logic
 *
 * We dont want any DOM manipulation here, because we
 * are using ReactJS now, so remove any document.getElementById
 * or any other DOM related code.
 *
 * Modify your previous functions so that they return
 * string(or any other data type) values so that we
 * can then use them in our components
 *
 * You have to export the function so that you can
 * import it in app.js
 * */
export function caesarEncrypt(clearText, shiftNum, shiftLeft) {
  /*
   *  I am just reversing the input here, but you should return
   *  the encrypted text
   */
  return clearText.split("").reverse().join("");
  // if (shiftLeft === true) {
  //   shiftNum = shiftNum * -1;
  // }
  // var temp;
  // for (let i = 0; i < clearText.length; i++) {
  //   if (upper(clearText[i])) {
  //     temp = (clearText.charCodeAt(i) + shiftNum - 65) % 26;
  //     if (temp < 0) temp += 26;
  //     output += String.fromCharCode(temp + 65);
  //   } else {
  //     temp = (clearText.charCodeAt(i) + shiftNum - 97) % 26;
  //     if (temp < 0) temp += 26;
  //     output += String.fromCharCode(temp + 97);
  //   }
  // }

  // return output;
}
