import React, { Component } from "react";
import "./styles.css";
// We are importing the caesarEncrypt function from our js file
import { caesarEncrypt } from "./Project1";

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      clearText: "",
      encryptedText: ""
    };
  }

  /*
   * This function handles the change event for the text box.
   * You need to add handlers for the other input elements
   */
  textChangeHandler(e) {
    /*
     * You have to call the caesarEncrypt function with values
     * from the input elements. Right now I am only using the text
     * input element, but you have to tie up the shift num and
     * shift left checkbox yourself
     */

    // getting the value from the input element
    var clearText = e.target.value;
    // updating the state, so that it reflects in the UI
    /*
     * calliing the caesarEncrypt function with the text the user entered
     * You have to get the values of the other inputs
     * HINT: Store other input in state and use them
     */
    var encryptedText = caesarEncrypt(clearText, 2, true);
    /**
     * Update the state to have the encrypted text
     */
    this.setState({ encryptedText, clearText });
  }

  render() {
    return (
      <div className="App">
        <label for="clearText"> Clear Text </label>
        {/*
         * Tied input element to a state variable
         * Added change handler to update the value
         * Will call encrypt function inside the change handler
         */}
        <input
          type="text"
          name="clearText"
          id="clearText"
          onChange={this.textChangeHandler.bind(this)}
          value={this.state.clearText}
        />
        <br />
        <br />
        <p>Caesar Ciphertext:</p>
        {/* Showing the result here */}
        <p>{this.state.encryptedText}</p>
        <br />
      </div>
    );
  }
}
